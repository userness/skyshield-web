document.addEventListener("DOMContentLoaded", () => {
  const logsTable = document.getElementById("logs-table");

  chrome.storage.local.get({ logs: [] }, (data) => {
    const logs = data.logs;

    if (logs.length === 0) {
      logsTable.innerHTML = `<tr><td colspan="4">No logs found.</td></tr>`;
      return;
    }

    logsTable.innerHTML = logs.map(log => `
      <tr>
        <td>${log.fileName}</td>
        <td class="${log.status.toLowerCase()}">${log.status}</td>
        <td>${log.timestamp}</td>
        <td><a href="${log.detailsUrl}" target="_blank">View</a></td>
      </tr>
    `).join("");
  });
});
