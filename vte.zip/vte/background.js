// VirusTotal API key (replace with your own)
const VIRUSTOTAL_API_KEY = "887ecd82e2bf4196f38599010c2f09197acf453c3a7a041417d3479d8c752f3d";





// Compute file hash using SHA-256
function computeHash(file, algorithm = "SHA-256") {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      crypto.subtle.digest(algorithm, reader.result)
        .then(hash => {
          resolve(Array.from(new Uint8Array(hash))
            .map(b => b.toString(16).padStart(2, "0"))
            .join(""));
        })
        .catch(reject);
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
}

// Query VirusTotal for hash information
async function queryVirusTotal(hash) {
  const url = `https://www.virustotal.com/api/v3/files/${hash}`;
  const response = await fetch(url, {
    headers: { "x-apikey": VIRUSTOTAL_API_KEY }
  });
  if (!response.ok) throw new Error(`Error fetching VirusTotal: ${response.statusText}`);
  return response.json();
}

// Check if the file is malicious
function isFileMalicious(result) {
  const stats = result.data.attributes.last_analysis_stats;
  return stats.malicious > 0 || stats.suspicious > 0;
}

// Save log to Chrome storage
function saveLog(logEntry) {
  chrome.storage.local.get({ logs: [] }, (data) => {
    const logs = data.logs;
    logs.push(logEntry);
    chrome.storage.local.set({ logs });
  });
}

// Show notification for malicious files
function showNotification(fileName, detailsUrl) {
  chrome.tabs.create({ url: chrome.runtime.getURL("virus_detected.html") });
  chrome.notifications.create({
    type: "basic",
    iconUrl: "icon.png",
    title: "Malicious File Detected",
    message: `The file "${fileName}" has been flagged as malicious.`,
    buttons: [{ title: "View Details" }]
  });

  chrome.notifications.onButtonClicked.addListener((notifId, buttonIndex) => {
    if (buttonIndex === 0) {
      chrome.tabs.create({ url: detailsUrl });
    }
  });
}

// Triggered when a download completes
chrome.downloads.onChanged.addListener(async (delta) => {
  if (!delta.state || delta.state.current !== "complete") return;

  chrome.downloads.search({ id: delta.id }, async ([downloadItem]) => {
    if (!downloadItem || !downloadItem.filename) return;

    try {
      const fileBlob = await fetch(downloadItem.finalUrl).then(res => res.blob());
      const fileHash = await computeHash(fileBlob);
      const vtResult = await queryVirusTotal(fileHash);

      const isMalicious = isFileMalicious(vtResult);
      const logEntry = {
        fileName: downloadItem.filename,
        hash: fileHash,
        status: isMalicious ? "Malicious" : "Safe",
        timestamp: new Date().toLocaleString(),
        detailsUrl: `https://www.virustotal.com/gui/file/${fileHash}`
      };

      saveLog(logEntry);

      if (isMalicious) {
        showNotification(downloadItem.filename, logEntry.detailsUrl);
      }
    } catch (error) {
      console.error("Error processing file:", error);
    }
  });
});